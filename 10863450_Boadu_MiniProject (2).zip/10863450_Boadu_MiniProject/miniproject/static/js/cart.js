const fetchCart = async () => {
  const response = await fetch("https://jijiapi-2n80.onrender.com/api/carts", {
    method: "GET",
  });

  const cart = await response.json();
  return cart;
};

async function main() {
  const cart = await fetchCart();

  cart.forEach((item) => {
    const inner = document.querySelector(".c-inner1");
    inner.innerHTML = `<div class="cart-item">
<img class="cart-img" src="images/ads/house1.jpg" alt="">
<div class="cart-info">
    <p>3 Bedroom Apartment Fully Furnished</p>
    <p><small>In Stock</small></p>
    <p class="cart-info-price">GH₵ 440,000</p>
</div>
<div class="cart-quantity-remove">
    <button class="cart-trash">
        <i class="fa-solid fa-trash-can"></i>
    </button>

    <form class="quantity" action="">
        <button>
            <i class="fa-solid fa-plus"></i>
        </button>
        <input type="number" name="" id="">
        <button>
            <i class="fa-solid fa-minus"></i>
        </button>
    </form>
</div>
</div> `;
  });
}

main();
