document.addEventListener('DOMContentLoaded', function() {
    const wrapper = document.querySelector('.c-inner2-wrapper');
    const container = document.querySelector('.c-inner2');
    const navbarHeight = 55; // Height of the navbar

    function onScroll() {
        const containerRect = container.getBoundingClientRect();
        const wrapperRect = wrapper.getBoundingClientRect();

        if (containerRect.bottom <= navbarHeight + wrapperRect.height) {
            wrapper.style.position = 'absolute';
            wrapper.style.bottom = '0';
            wrapper.style.top = 'auto';
            wrapper.style.width = '100%'; // Maintain the width
        } else if (containerRect.top <= navbarHeight) {
            wrapper.style.position = 'fixed';
            wrapper.style.top = `${navbarHeight}px`;
            wrapper.style.bottom = 'auto';
            wrapper.style.width = `${containerRect.width}px`; // Maintain the width
        } else {
            wrapper.style.position = 'absolute';
            wrapper.style.top = '0';
            wrapper.style.bottom = 'auto';
            wrapper.style.width = '100%'; // Maintain the width
        }
    }

    window.addEventListener('scroll', onScroll);
    window.addEventListener('resize', onScroll); // Adjust on resize
    onScroll(); // Initialize on page load
});
