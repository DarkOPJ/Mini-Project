const fetchProducts = async () => {
  const response = await fetch("https://jijiapi-2n80.onrender.com/api/products", {
    method: "GET",
  });

  const products = await response.json();
  return products;
};


const main = async () => {
  let products = await fetchProducts();
  console.log(products)

  const menu = document.querySelector(".menu");
  const category_opts = document.querySelector("#category_filter");
  const region_opts = document.querySelector("#region_filter");
  products.categories.forEach((category) => {
    const outerLink = document.createElement("a");
    outerLink.classList.add("opts");
    outerLink.dataset.category = category.name;

    const imageDiv = document.createElement("div");
    imageDiv.classList.add("opt_pic");

    const image = document.createElement("img");
    image.src = "/static/images/menu1/vehicles.png";

    imageDiv.appendChild(image);

    const textDiv = document.createElement("div");
    textDiv.classList.add("opt_text");

    const innerText1 = document.createElement("p");
    innerText1.classList.add("text_1");
    innerText1.innerText = category.name;

    const innerText2 = document.createElement("p");
    innerText2.classList.add("text_2");
    innerText2.innerText = "77,600 ads";

    const svg = document.createElement("div");
    svg.classList.add("svg1");

    const font = document.createElement("i");
    font.classList.add("fa-solid", "fa-chevron-right", "arrow_icon");

    svg.appendChild(font);

    textDiv.appendChild(innerText1);
    textDiv.appendChild(innerText2);
    textDiv.appendChild(svg);

    outerLink.appendChild(imageDiv);
    outerLink.appendChild(textDiv);

    menu.appendChild(outerLink);

    const opt = document.createElement("option");
    opt.value = category.id;
    opt.innerText = category.name;

    category_opts.appendChild(opt);
  });

  products.regions.forEach((region) => {
    const opt = document.createElement("option");
    opt.value = region.id;
    opt.innerText = region.name;

    region_opts.appendChild(opt);
  });

  const innerAdDiv = document.querySelector(".inner_2_2_2_ads");
  products.products.forEach((product, index) => {
    const ad = document.createElement("div");
    ad.classList.add("ad");

    const adDiv = document.createElement("div");
    adDiv.classList.add("ad_div");

    const adPic = document.createElement("div");
    adPic.classList.add("ad_pic", `pic${index + 1}`);

    const link = document.createElement("a");
    link.classList.add("bookmark");

    const font = document.createElement("i");
    font.classList.add("fa-regular", "fa-bookmark");

    link.appendChild(font);

    const top = document.createElement("div");
    top.classList.add("top", "top1");

    const p = document.createElement("p");
    p.innerText = "TOP";

    top.appendChild(p);

    const number = document.createElement("div");
    number.classList.add("number");

    const numberP = document.createElement("p");
    numberP.innerText = "6";

    number.appendChild(numberP);

    adPic.appendChild(link);
    adPic.appendChild(top);
    adPic.appendChild(number);

    adDiv.appendChild(adPic);
    const p1 = document.createElement("p");
    p1.innerText = product.name;

    const p2 = document.createElement("p");
    p2.innerText = `Gh₵ ${product.price}`;
    p2.classList.add("price");

    adDiv.appendChild(p1);
    adDiv.appendChild(p2);

    ad.appendChild(adDiv);

    innerAdDiv.appendChild(ad);
  });

  const filters = document.querySelector(".filters");
  const min = document.querySelector("#minimum");
  const max = document.querySelector("#maximum");
  const applyButton = document.querySelector(".apply");
  const clearButton = document.querySelector(".clear");

  clearButton.addEventListener("click", () => {
    filters.reset();
    products.products.forEach((product, index) => {
      const ad = document.createElement("div");
      ad.classList.add("ad");

      const adDiv = document.createElement("div");
      adDiv.classList.add("ad_div");

      const adPic = document.createElement("div");
      adPic.classList.add("ad_pic", `pic${index + 1}`);

      const link = document.createElement("a");
      link.classList.add("bookmark");

      const font = document.createElement("i");
      font.classList.add("fa-regular", "fa-bookmark");

      link.appendChild(font);

      const top = document.createElement("div");
      top.classList.add("top", "top1");

      const p = document.createElement("p");
      p.innerText = "TOP";

      top.appendChild(p);

      const number = document.createElement("div");
      number.classList.add("number");

      const numberP = document.createElement("p");
      numberP.innerText = "6";

      number.appendChild(numberP);

      adPic.appendChild(link);
      adPic.appendChild(top);
      adPic.appendChild(number);

      adDiv.appendChild(adPic);
      const p1 = document.createElement("p");
      p1.innerText = product.name;

      const p2 = document.createElement("p");
      p2.innerText = `Gh₵ ${product.price}`;
      p2.classList.add("price");

      adDiv.appendChild(p1);
      adDiv.appendChild(p2);

      ad.appendChild(adDiv);

      innerAdDiv.appendChild(ad);
    });
  });

  applyButton.addEventListener("click", async () => {
    const selectedRegion = region_opts.value;
    const selectedCategory = category_opts.value;
    const setMin = min.value;
    const setMax = max.value;

    const filteredProducts = await fetch(
      `https://jijiapi-2n80.onrender.com/api/products?category_id=${selectedCategory}&region_id${selectedRegion}&min_price=${setMin}&max_price=${setMax}`,
      {
        method: "GET",
      }
    );

    const filtered = await filteredProducts.json();

    innerAdDiv.innerHTML = "";

    filtered.products.forEach((product, index) => {
      const ad = document.createElement("div");
      ad.classList.add("ad");

      const adDiv = document.createElement("div");
      adDiv.classList.add("ad_div");

      const adPic = document.createElement("div");
      adPic.classList.add("ad_pic", `pic${index + 1}`);

      const link = document.createElement("a");
      link.classList.add("bookmark");

      const font = document.createElement("i");
      font.classList.add("fa-regular", "fa-bookmark");

      link.appendChild(font);

      const top = document.createElement("div");
      top.classList.add("top", "top1");

      const p = document.createElement("p");
      p.innerText = "TOP";

      top.appendChild(p);

      const number = document.createElement("div");
      number.classList.add("number");

      const numberP = document.createElement("p");
      numberP.innerText = "6";

      number.appendChild(numberP);

      adPic.appendChild(link);
      adPic.appendChild(top);
      adPic.appendChild(number);

      adDiv.appendChild(adPic);
      const p1 = document.createElement("p");
      p1.innerText = product.name;

      const p2 = document.createElement("p");
      p2.innerText = `Gh₵ ${product.price}`;
      p2.classList.add("price");

      adDiv.appendChild(p1);
      adDiv.appendChild(p2);

      ad.appendChild(adDiv);

      innerAdDiv.appendChild(ad);
    });
  });
};

main();
