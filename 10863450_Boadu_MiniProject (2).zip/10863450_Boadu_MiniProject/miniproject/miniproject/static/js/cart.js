const fetchCart = async () => {
  const response = await fetch("https://jijiapi-2n80.onrender.com/api/carts", {
    method: "GET",
  });

  const cart = await response.json();
  return cart;
};

async function main() {
  const cart = await fetchCart();

  cart.forEach((item) => {
    const inner = document.querySelector(".c-inner1");
    inner.innerHTML = `<div class="cart-item">
<img class="cart-img" src="/static/images/ads/house1.jpg" alt="">
<div class="cart-info">
    <p>${item.product_id.name}</p>
    <p><small>${item.product_id.stock_quantity} In Stock</small></p>
    <p class="cart-info-price">GH₵ ${item.product_id.price}</p>
</div>
<div class="cart-quantity-remove">
    <button class="cart-trash" data-id="${item.id}">
        <i class="fa-solid fa-trash-can"></i>
    </button>

    <form class="quantity" action="">
        <button>
            <i class="fa-solid fa-plus"></i>
        </button>
        <input type="number" name="" id="">
        <button>
            <i class="fa-solid fa-minus"></i>
        </button>
    </form>
</div>
</div> `;
  });

  const deleteButton = document.querySelector('.cart-trash');
  deleteButton.addEventListener('click', async () => {
    const response = await fetch('https://jijiapi-2n80.onrender.com/api/carts')
  })
}

main();
