const main2 = async () => {
    const products = await fetchProducts();

    const menu2 = document.querySelector('.menu2');
    products.categories.forEach((category, index) => {
        const outerLink1 = document.createElement('a');
        outerLink1.classList.add('item')

        const imageDiv1 = document.createElement('div');
        imageDiv1.classList.add('img2', `sqr${index + 1}`);

        const text1 = document.createElement('p');
        text1.classList.add('p_ad1');
        text1.innerText = category.name;

        outerLink1.appendChild(imageDiv1);
        outerLink1.appendChild(text1);

        menu2.appendChild(outerLink1);
    });
}

main2();